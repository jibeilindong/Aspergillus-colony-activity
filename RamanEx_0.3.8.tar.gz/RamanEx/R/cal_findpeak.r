cal_findpeak <- function(all_data,step = 0.00001)
{
  hyperspec_spc_Under <- as.data.frame(all_data)
  hyperspec_spc_all <- as.data.frame(pre_der(all_data))
  
  peak_location_list <- Unspike_list <- list()
  for(j in 1:nrow(hyperspec_spc_all))
  {
    hyperspec_spc <- hyperspec_spc_all[j,-1]
    hyperspec_spc_Under_i <- hyperspec_spc_Under[j,-1]
    wavenumber <- as.numeric(names(hyperspec_spc))
    position_noise <-  c(which(hyperspec_spc > step),-(which(hyperspec_spc < -step)))
    range_noise <- peak_range(position_noise)
    k <- 1
    peak_location <- c()
    for (i in 1:length(range_noise))
    {
      lm_data <- hyperspec_spc[range_noise[[i]][1]:abs(range_noise[[i]][2])]
      lm_data_y <- as.vector(t(lm_data))
      lm_data_x <- as.numeric(names(lm_data))
      lm_fomula <- lm(lm_data_y~lm_data_x)
      if(summary(lm_fomula)$r.squared > 0.6 & lm_fomula$coefficients[2] < 0)
      {
        wave <- -lm_fomula$coefficients[1]/lm_fomula$coefficients[2]
        peak_location_i <- which.min(abs(wavenumber - wave))
        # peak_location_i <- peak_location_i - 3 + which.max(hyperspec_spc_Under_i[,(peak_location_i-2):(peak_location_i+2)])
        # peak_location[k] <- peak_location_i
        # k <- k +1
        if(hyperspec_spc_Under_i[,peak_location_i] > max(hyperspec_spc_Under_i)/30)
        {
          peak_location[k] <- wavenumber[peak_location_i]
          k <- k +1
        }
      }
    }
    if (sum(peak_location) != 0) {
      peak_location_list[[as.character(hyperspec_spc_Under[j,1])]] <- peak_location
    }
  }
  return(peak_location_list)
}

peak_range <- function(position) 
{
  position <- position[order(abs(position))]
  double_value <- list()
  k <- 1
  for (i in 1:length(position))
  {
    if (i == 1 & position[1] != 1)
    {
      double_value[[1]] <- c(1,position[1])
      k <- 2
    }else if (i != length(position) & position[i+1] < 0 & position[i] > 0)
    {
      double_value[[k]] <- c(position[i],position[i+1])
      k <- k+1
    }
  }
  return(double_value)
}
