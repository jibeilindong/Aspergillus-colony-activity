#' find spikes
#'
#' @param hyperspec = hyperspec
#' @param width: the threshold of [width of half peak]
#' @param threshold: the threshold of [height/width of half peak],
#'                   we think it's a spike if it has a larger value.
#' @return a spike_list(sample_i_ind and wavenumber_ind)
#' @examples
#' pre_spike_find(hyperspec, width = 5)
#'
convolve_matrix <- function(mat, kernel) {
  # 用R的内置函数embed进行卷积操作
  rows <- sapply(1:nrow(mat), function(i) {
    row <- mat[i, ]
    convolve(row, kernel, type = "open")
  })
  
  cols <- sapply(1:ncol(rows), function(i) {
    col <- rows[, i]
    convolve(col, kernel, type = "open")
  })
  
  # 由于卷积操作的结果比原始矩阵的大小要大，因此需要对结果进行裁剪
  result <- t(cols[(length(kernel)+1):(length(kernel)+ncol(mat)),])
  return(result)
}

pre_spike_matrix <- function(all_data,slope_1 = 1,slope_2 = 100) {

  all_spc <- as.matrix(all_data[,-1])
  all_spc <- matrix(all_spc, nrow = nrow(all_spc), ncol = ncol(all_spc), byrow = FALSE)
  slope_inds_1 <- which(all_spc > slope_1,arr.ind = TRUE)
  kernel_ori <- matrix(c(-1,-1,-1, -1,-1,-1, -1,-1,-1, -1,-1,
                     -1,-1,-1, -1,-1,33, -1,-1,-1, -1,-1,
                     -1,-1,-1, -1,-1,-1, -1,-1,-1, -1,-1),nrow = 3)

  all_spc_1 <- convolve_matrix(all_spc, kernel_ori)
  slope_inds_2 <- which(all_spc_1 > slope_2,arr.ind = TRUE)
  
  slope_inds <- unique(rbind(slope_inds_1, slope_inds_2))
  
  spc_new <- all_data
  wavenumber <- as.numeric(as.character(colnames(spc_new[,-1])))
  
  
  
  for (ind in unique(slope_inds[,1])) {
    spike_pos <- slope_inds[which(slope_inds[,1] == ind),2]
    if(ind <= 3 ) { inds_new <- c((ind+1):(ind+3))}
    if(ind > 3 & ind <= (nrow(all_data)-3)) { inds_new <- c((ind-3):(ind-1),(ind+1):(ind+3))}
    if(ind > (nrow(all_data)-3) ) { inds_new <- c((ind-3):(ind-1))}
    
    for(i in spike_pos){
      if (i == 1) {
        spc_new[ind, 2:4] <- colMeans(spc_new[inds_new,2:4])
      } else if (i >= (length(wavenumber))) {
        spc_new[ind, (i-2):i] <- colMeans(spc_new[inds_new,(i-2):i])
      } else {
        spc_new[ind, i:(i+2)] <- colMeans(spc_new[inds_new,i:(i+2)])
      }
    }
  }
  
  return(spc_new)
}
