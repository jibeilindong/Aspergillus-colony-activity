plot_stack_mean <- function(data_hyperSpec, group_same, group_diff, stack_height = 0.1) {
  
  meta_data <- dplyr::select(
    as.data.frame(data_hyperSpec@data),
    all_of(c(group_same, group_diff))
  )

  data_hyperSpec_melt <- spc_melt(
    data_hyperSpec,
    meta_group = c(group_same, group_diff),
    from = floor(min(data_hyperSpec@wavelength)),
    to = ceiling(max(data_hyperSpec@wavelength))
  )

  melt_summary <- Rmisc::summarySE(data_hyperSpec_melt, measurevar = "value",groupvars = c(names(meta_data), "wavenumber"))

  levels <- levels(factor(melt_summary[, group_diff]))
  n <- length(levels) * stack_height
  for (i in levels) {
    melt_summary[which(melt_summary[group_diff] == i), ]$value <-
      melt_summary[which(melt_summary[group_diff] == i), ]$value + n
    n <- n - stack_height
  }

  plot_stack_mean <- ggplot(melt_summary,aes(x = wavenumber, y = value, group = get(group_diff))) +
    geom_ribbon(aes(ymin = value - sd,ymax = value + sd,group = get(group_diff)),alpha = 0.3) +
    geom_line(aes(color = get(group_diff)), size = 0.5) +
    facet_wrap(. ~ get(group_same), ncol = 2) +
    xlab(expression(paste("Wavenumber (cm"^"-1", ")", sep = ""))) +
    ylab("Normalized Intensity (a.u.)") +
    scale_x_continuous(breaks = seq(0, 4000, 500)) +
    theme_bw() +
    theme(
      panel.grid = element_blank(),
      text = element_text(color = "black"),
      axis.title.x = element_text(size = 15),
      axis.title.y = element_text(size = 15),
      axis.text.x = element_text(size = 10),
      axis.text.y = element_blank(),
      axis.ticks.x = element_line(size = 1),
      axis.ticks.y = element_blank(),
      legend.position = "right",
      legend.title = element_blank(),
      legend.text = element_text(size = 10),
      strip.background = element_rect(fill = "white"),
      strip.text = element_text(size = 15),
    ) +
    if (class(melt_summary[1, group_diff]) == "numeric") {
      scale_color_distiller(palette = "RdYlBu")
    } else {
      scale_fill_brewer(palette = "Set2")
    }

  return(plot_stack_mean)
}
