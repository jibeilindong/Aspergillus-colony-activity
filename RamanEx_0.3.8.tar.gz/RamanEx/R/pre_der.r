#' The difference method computes the first derivative of the spectrum
#'
#' @param hyperspec the spec as hyperspec object
#' @param step  calculate the derivative by moving half a step(odd) forward and backward
#'
#' @return the first derivative of the spectrum as hyperspec object
#' @export
#'
#' @examples
#' data_baseline_normalization_der <- Der(data_baseline_normalization, step = 3)
pre_der <- function(all_data, step = 3) {

  spc_ori <- as.matrix(all_data[,-1])
  wavenumber <- as.numeric(colnames(all_data[,-1]))
  halfwidth <- (step - 1) / 2

  spc_der <- matrix(data = NA, nrow = nrow(spc_ori), ncol = (ncol(spc_ori) - (step - 1)))
  for (j in (1 + halfwidth):(ncol(spc_ori) - halfwidth)) {
    spc_der[,(j-1)] <- (spc_ori[, j + halfwidth] - spc_ori[, j - halfwidth]) /
      (wavenumber[j + halfwidth] - wavenumber[j - halfwidth])
  }
  spc_der <- data.table(all_data[,1],spc_der)
  wavenumber_new <- wavenumber[(1 + halfwidth):(ncol(spc_ori) - halfwidth)]
  colnames(spc_der) <- c(colnames(all_data)[1],wavenumber_new)
  
  print(paste("输出数据包含", nrow(spc_der), "条光谱", sep = ""))
  return(spc_der)
}
