plot_findpeak <- function(data_table_mean,peak_list = Unspike_list,stack_height = 0.001){
  
  hs_spc <- data_table_mean
  spc_mean_df_melt <- data.table(melt(hs_spc,id.vars = "Group",variable.name = "wavenumber",value.name = "intensity"))
  # spc_mean_df_melt <- spc_mean_df_melt %>% 
  #   group_by(Group) %>% 
  
  setkey(spc_mean_df_melt,Group,wavenumber)
  Group_levels <- levels(factor(spc_mean_df_melt$Group))
  
  n <- length(peak_list) * stack_height
  for (i in 1:length(peak_list)) {
    spc_mean_df_melt[which(spc_mean_df_melt$Group == Group_levels[i]), ]$intensity <-
      spc_mean_df_melt[which(spc_mean_df_melt$Group == Group_levels[i]), ]$intensity + n
    n <- n - stack_height
  }
  spc_mean_df_melt$wavenumber <- as.numeric(as.character(spc_mean_df_melt$wavenumber))
  spc_mean_df_melt$intensity_sel <- spc_mean_df_melt$intensity
  ogic <- c()
  for(i in 1:length(peak_list))
  {
    wavenumber_i <- spc_mean_df_melt[which(spc_mean_df_melt$Group == Group_levels[i])]$wavenumber
    ogic_i <- wavenumber_i %in% wavenumber_i[peak_list[[i]]]
    ogic <- c(ogic,ogic_i)
  }

  spc_mean_df_melt$intensity_sel[ogic == FALSE] <- NA
  

  plot_sel <- ggplot(spc_mean_df_melt, aes(x = wavenumber, y = intensity)) +
    geom_line(aes(group = Group)) +  
    geom_point(aes(x = wavenumber, y = intensity_sel),
               colour = "grey90", fill = "red", shape = 21, alpha = 0.8, size = 2.5) +
    #ggtitle(paste(group_name, " = ", level, "\nmark = ", mark, sep = "")) +
    xlab(expression(paste("Wavenumber (cm"^"-1", ")", sep = ""))) +
    ylab("Normalized Intensity (a.u.)") +
    scale_x_continuous(breaks = seq(0, 4000, 200)) +
    theme_bw() +
    theme(
      panel.grid = element_blank(),
      text = element_text(color = "black"),
      plot.title = element_text(hjust = 0.5, size = 15, face = "bold"),
      axis.title.x = element_text(size = 15),
      axis.title.y = element_text(size = 15),
      axis.text.x = element_text(size = 10),
      axis.text.y = element_text(size = 10),
      axis.ticks.x = element_line(size = 1),
      axis.ticks.y = element_line(size = 1)
    )
  plot_sel
  return(plot_sel)
}


