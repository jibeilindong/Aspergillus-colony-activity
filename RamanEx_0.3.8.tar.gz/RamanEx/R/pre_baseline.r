### baseline
#' Calculate the baseline of the spectrum and subtract
#'
#' @param data_hyperSpec: data_hyperSpec
#' @return a baselined spc as data_hyperSpec object
#' @examples
#'
pre_baseline <- function(spc, order = 1) {
  wavenumber <- as.numeric(colnames(spc[,-1]))
  spc2hs <- new("hyperSpec",spc = spc[,-1],wavelength = wavenumber)
  
  data_hyperSpec <- spc2hs
  wave_max <- max(data_hyperSpec@wavelength)
  wave_min <- min(data_hyperSpec@wavelength)

  hyperspec <- data_hyperSpec
  if (wave_max > 3050 & wave_min < 600) {
    hyperspec_1 <- hyperspec[, , c(500 ~ 1790)] - 
      spc.fit.poly.below(hyperspec[,, c(500 ~ 1790)], hyperspec[, , c(500 ~ 1790)], poly.order = 1)
    hyperspec_2 <- hyperspec[,, c(1800 ~ 3050)] - 
      spc.fit.poly(hyperspec[,, c(1800 ~ 2065, 2300 ~ 2633, 2783, 3050)], hyperspec[,, c(1800 ~ 3050)], poly.order = 6)
    hyperspec_baseline <- cbind(hyperspec_1, hyperspec_2)
    print(paste("输出数据包含", length(hyperspec_baseline), "条光谱", sep = ""))
  }
  else if (wave_max > 1750 & wave_min < 600) {
    hyperspec_baseline <- hyperspec[, , c(500 ~ 1750)] - 
      spc.fit.poly.below(hyperspec[, , c(500 ~ 1750)], hyperspec[, , c(500 ~ 1750)], poly.order = order)
    print(paste("输出数据包含", length(hyperspec_baseline), "条光谱", sep = ""))
  }
  else if (wave_max > 3050 & wave_min < 1800 & wave_min > 600) {
    hyperspec_baseline <- hyperspec[, , c(1800 ~ 3050)] - 
      spc.fit.poly(hyperspec[, , c(1800 ~ 2065, 2300 ~ 2633, 2783, 3050)], hyperspec[, , c(1800 ~ 3050)], 
                   poly.order = order)
    print(paste("输出数据包含", length(hyperspec_baseline), 
                "条光谱", sep = ""))
  }
  else if (wave_max <= 3050 & wave_max > 1750 & wave_min < 1000 & wave_min > 600){
    hyperspec_baseline <- hyperspec[, , c(600 ~ 1750)] - 
      spc.fit.poly.below(hyperspec[,, c(600 ~ 1750)], hyperspec[, , c(600 ~ 1750)], poly.order = 1)
  }
  else if (wave_max < 1750 & wave_min > 600) {
    print("the spc is too small to baseline")
  }
  else {
    print("your spc data 有问题!")
  }
  
  data_hyperSpec_baseline <- hyperspec_baseline
  # if (wave_max > 3040 && wave_min < 600) {
  #   data_hyperSpec_1 <- data_hyperSpec[, , c(500 ~ 1720)] -
  #     spc.fit.poly.below(data_hyperSpec[, , c(500 ~ 1720)],
  #       data_hyperSpec[, , c(500 ~ 1720)],
  #       poly.order = order1
  #     )
  #   data_hyperSpec_2 <- data_hyperSpec[, , c(1720 ~ 3050)] -
  #     spc.fit.poly(data_hyperSpec[, , c(1720 ~ 2065, 2300 ~ 2633, 2783, 3050)],
  #       data_hyperSpec[, , c(1720 ~ 3050)],
  #       poly.order = order2
  #     )
  #   data_hyperSpec_baseline <- cbind(data_hyperSpec_1, data_hyperSpec_2)
  # } else if (wave_max > 1720 && wave_min < 600) {
  #   data_hyperSpec_baseline <- data_hyperSpec[, , c(500 ~ 1720)] -
  #     spc.fit.poly.below(data_hyperSpec[, , c(500 ~ 1720)],
  #       data_hyperSpec[, , c(500 ~ 1720)],
  #       poly.order = order1
  #     )
  # } else if (wave_max > 3040 && wave_min < 1720 && wave_min > 600) {
  #   data_hyperSpec_baseline <- data_hyperSpec[, , c(1720 ~ 3050)] -
  #     spc.fit.poly(data_hyperSpec[, , c(1720 ~ 2065, 2300 ~ 2633, 2783, 3050)],
  #       data_hyperSpec[, , c(1720 ~ 3050)],
  #       poly.order = order2
  #     )
  # } else if (wave_max < 1720 & wave_min > 600) {
  #   print("光谱太短，无法校正基线！")
  # } else {
  #   print("光谱数据有问题！")
  # }

  spc_baseline <- cbind(filename = spc$filename,as.data.frame(data_hyperSpec_baseline$spc))
  spc_baseline <- spc_baseline[,!duplicated(colnames(spc_baseline))]
  return(spc_baseline)
}


# install.packages("baseline")
# library("baseline")
# 
# spec <- read.csv("/Users/chenrongze/Myprogrames/1_PhD/念珠菌实验/念珠菌实验/3_真菌耐药/Fig-1_真菌耐药性规律探究与快检方法/6258_耐药规律/Raman/Batch 2/5-FC/5_60_1h_2_cell_20_13_50_48.txt",sep = "\t",header = F)
# # Extract the wavelength and intensity columns
# wavelength <- spec[,1]
# intensity <- spec[,2]
# intensity <- as.matrix(intensity)
# # Calculate the baseline using the "baseline" function
# intensity_matrix <- matrix(intensity, nrow=1)
# baseline_la <- baseline.als(spectra=intensity_matrix, lambda=6, p = 0.01,maxit = 50)
# 
# #corrected_intensity <- intensity_matrix - baseline
# 
# # Plot the original intensity and corrected intensity for comparison
# plot(wavelength, intensity, type="l", col="blue", xlab="Wavelength", ylab="Intensity")
# lines(wavelength, baseline_la[[1]], type="l", col="red")
# legend("topright", c("Original Intensity", "Corrected Intensity"), col=c("blue", "red"), lty=c(1,1))
# 
