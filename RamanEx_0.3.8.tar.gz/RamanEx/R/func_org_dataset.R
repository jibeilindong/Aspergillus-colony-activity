func_org_dataset <- function(all_data_spc,Name_group)
{
  train_data <- as.data.table(all_data_spc)
  
  factor_alldata <- select(train_data,all_of(Name_group)) #记得更改这里
  factor_alldata <- unique(factor_alldata)
  setkeyv(train_data,Name_group) #和这里
  
  training_set <- c()
  for (i in 1:nrow(factor_alldata))
  {
    training_set_i <- sample(train_data[factor_alldata[i,]],(0.7*nrow(train_data[factor_alldata[i,]]))%/%1)
    training_set <- rbind(training_set,training_set_i)
  }

  test_set <- train_data %>% filter(Number %in% setdiff(train_data$Number,training_set$Number))
  return(list(training_set,test_set))
}
