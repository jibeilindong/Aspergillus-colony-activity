#' Title
#'
#' @param CD_ratio_groups 
#'
#' @return
#' @export
#'
#' @examples
plot_CDR_box <- function(CD_ratio_groups)
{
  plot <-ggplot(CD_ratio_groups,aes(x = factor(Group),y = CD_ratio,group = Group,fill = Group)) +
    geom_point(aes(group = Group, color = Group), position = position_jitter(0.2)) +
    geom_boxplot(aes(group = Group),alpha = 0.2,outlier.alpha = 0) +
    geom_hline(aes(yintercept = 0.01), colour = "red", linetype = "dashed", size = 1) +
    default_theme() +
    theme(
      legend.position = "none",
      axis.text.x = element_text(size = 15, angle = 45,hjust = 1,vjust = 1)) +
    xlab("Group") +
    ylab('Metabolic activity (CD-ratio)')
  
  return(plot)
}