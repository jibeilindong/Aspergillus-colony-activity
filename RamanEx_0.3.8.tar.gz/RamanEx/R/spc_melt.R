#' 数据调整成适于画光谱的格式
#'
#' @param data
#' @param Meta_group
#' @param from
#' @param to
#' @return a dataframe with a filenames and all data
#'
#' @examples
spc_melt <- function(spc, meta_group, from, to) {
  
  data_hyperSpec_df_melt <- reshape2::melt(spc,
    id.vars = meta_group,
    variable.name = "wavenumber",
    value.name = "value"
  )

  data_hyperSpec_df_melt$wavenumber <- as.numeric(as.character(data_hyperSpec_df_melt$wavenumber))
  data_hyperSpec_df_melt <- dplyr::filter(data_hyperSpec_df_melt, wavenumber < to & wavenumber > from)

  return(data_hyperSpec_df_melt)
}
