#' 根据Group列的分组进行单细胞光谱保存
#' 输出单个光谱数据保存在文件夹

save_single_cell <- function(outpath, output_folder, data_hyperSpec) {
  full_outpath <- paste(outpath, output_folder, sep = "/")
  dir.create(full_outpath)

  groups <- levels(factor(data_hyperSpec$Group))
  for (group in groups) {
    data_hyperSpec_group <- data_hyperSpec[data_hyperSpec$Group == group]
    spc_df <- as.data.frame(data_hyperSpec_group$spc)
    meta_data <- data.frame(dplyr::select(as.data.frame(data_hyperSpec_group), -spc, -.row),
      metadata = gsub(".txt", "", data_hyperSpec_group$filename)
    )
    outpath_group <- paste(full_outpath, group, sep = "/")
    dir.create(outpath_group)

    for (i in (1:nrow(spc_df))) {
      single_cell <- data.frame(t(spc_df[i, ]))
      fwrite(single_cell,
        paste(outpath_group, "/", meta_data$metadata[i], "_", meta_data$Number[i], ".txt", sep = ""),
        row.names = T, col.names = F, quote = F, sep = "\t"
      )
    }
  }
}

save_single_cell_tb <- function(outpath, output_folder, spc_df,hs_meta) {
  full_outpath <- paste(outpath, output_folder, sep = "/")
  dir.create(full_outpath)

  groups <- levels(factor(hs_meta$Group))
  
  for (group in groups) {
    data_group <- hs_meta %>% filter(Group == group)
    spc_df_i <- spc_df %>% filter(filename %in% data_group$filename)
    outpath_group <- paste(full_outpath, group, sep = "/")
    dir.create(outpath_group)
    
    for (i in (1:nrow(spc_df_i))) {
      single_cell <- data.frame(t(spc_df_i[i,-1]))
      fwrite(single_cell,
             paste(outpath_group, "/", spc_df_i$filename[i], ".txt",sep = ""),
             row.names = T, col.names = F, quote = F, sep = "\t"
      )
    }
  }
  
  # for (i in (1:nrow(spc_df))) {
  #   filename_i <- spc_df[i,1]
  #   single_cell <- data.frame(t(spc_df[i, -1]))
  #   fwrite(single_cell,
  #          paste(full_outpath, "/", filename_i, ".txt", sep = ""),
  #          row.names = T, col.names = F, quote = F, sep = "\t"
  #   )
  # }
}
