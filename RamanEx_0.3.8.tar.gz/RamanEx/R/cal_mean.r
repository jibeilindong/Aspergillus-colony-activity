#' data_hyperSpec to spc_mean
#'
cal_mean <- function(hs_data,
                     meta_group,
                     save = TRUE,
                     outfolder = "spc_mean",
                     outpath = getwd()) {
  group_list <- as.list(dplyr::select(hs_data, all_of(meta_group)))
  spc_df <- as.data.frame(hs_data[,3:ncol(hs_data)])
  spc_mean_df <- aggregate(spc_df, group_list, mean)

  filenames <- apply(
    dplyr::select(spc_mean_df, starts_with("group")),
    1,
    function(i) paste(i, collapse = "_")
  )

  if (save == TRUE) {
    dir.create(paste(outpath, outfolder, sep = "/"))
    for (i in 1:nrow(spc_mean_df)) {
      cell <- data.frame(t(spc_mean_df[i, -1:-length(meta_group)]))
      fwrite(cell,
        paste(outpath, "/", outfolder, "/", filenames[i], ".txt", sep = ""),
        row.names = T, col.names = F, quote = F, sep = "\t"
      )
    }
  }
  return(spc_mean_df)
}
