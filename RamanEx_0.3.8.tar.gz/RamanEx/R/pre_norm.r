#' Normalization for multiple spectra or one spectrum
#'
#' @param data_hyperSpec = data_hyperSpec
#' @param from = 2500, to = 3000, at = 1660, method = "max"
#' @return a normalized spc as data_hyperSpec object
#' @examples
#' pre_norm(data_hyperSpec, from = 2500, to = 3000, at = 1660, method = "max")
#'
pre_norm <- function(spc, from = 2800, to = 3050, at = 1660, method = "max") {
  spc <- as.data.table(spc)
  wavenumber <- as.numeric(colnames(spc[,-1]))
  if (nrow(spc) > 1) {
    if (method == "max") {
      spc_factor <- apply(spc_waveumber(spc[,-1], from, to), 1, max)
    } else if (method == "sum") {
      spc_factor <- apply(spc_waveumber(spc[,-1], from, to), 1, sum)
    } else if (method == "single") {
      spc_factor <- spc[, , wavenumber[which.min(abs(wavenumber - at))]]
    } else {
      print("Error: method should be max/sum/single")
    }
  } else {
    if (method == "max") {
      spc_factor <- max(spc_waveumber(spc, from, to))
    } else if (method == "sum") {
      spc_factor <- sum(spc)
    } else if (method == "single") {
      spc_factor <- spc[, , wavenumber[which.min(abs(wavenumber - at))]]
    } else {
      print("Error: method should be max/sum/single")
    }
  }
  data_norm <- spc[,-1] / spc_factor
  data_norm <- cbind(filename = spc$filename,data_norm)
  return(data_norm)
}
