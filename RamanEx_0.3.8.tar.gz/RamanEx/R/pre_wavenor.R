#光谱以列向量形式输入，第一列为wavenumber，第二列为value
#返回值为行向量，标注了与输入峰对应的峰位置坐标
#以酰胺的信号为内参，先大致校准整条光谱，然后在区域内找到最近的信号

pre_wavenor <- function(spc, peaks, inter_ref = "Amide",window = 20, cycle = 2)
{
  spc <- data.frame(spc)
  if(inter_ref == "Amide")
  {
    inter_ref_up <- 1750
    inter_ref_down <- 1600
    inter_ref_band <- spc %$% .[wavenumber < inter_ref_up & wavenumber > inter_ref_down,]
    inter_ref_locate <- inter_ref_band[which.max(inter_ref_band[,2]), 1]
    inter_ref_theory <- peaks[peaks < inter_ref_up & peaks > inter_ref_down]
    norm_peaks <- peaks - inter_ref_theory + inter_ref_locate
    neighbors <- matrix(NA, 1, length(peaks))
    for (i in 1:length(peaks))
    {
      center <- spc[which.min(abs(spc[,1]-peaks[i])) ,1]
      range <- spc %$% .[wavenumber < center + window/2 & wavenumber > center - window/2,]
      if(nrow(spc) != 1)
      {
        temp_locate <- range[which.max(range[,2]),1]
      }else{
        temp_locate <- range[which.max(range),1]
      }
      if (temp_locate > 2000) { cycle = 6 }
      for (j in c(1:cycle))
      {
        temp_max_locate <- which(spc[,1] == temp_locate)
        temp_max <- spc[temp_max_locate, 2]
        region <- spc[(temp_max_locate-2):(temp_max_locate+2), ]
        if ( max(region[, 2]) != temp_max )
        {
          temp_locate <- region[which.max(region[,2]),1]
        }
      }
      neighbors[1,i] <- temp_locate
    }
  }else{
    print("Alarm! Your inter_ref should be Amide! OK?")
  }
  return (neighbors)
}


