cal_cor <- function(spc_mean_df, group_label, mark1 = 0.6, mark2 = 0.9) {
  spc_mean_df <- data.frame(spc_mean_df)
  colnames(spc_mean_df) <- gsub("X","",colnames(spc_mean_df))
    wavenumbers <- as.numeric(names(spc_mean_df)[-c(1,ncol(spc_mean_df))])
    group_col_ind <- grep(pattern = "group", names(spc_mean_df))

    cor_vec <- array()
    for (i in 2:(group_col_ind-1)) {
        cor_vec[i - 1] <- cor(spc_mean_df[,group_col_ind],spc_mean_df[,i],method = "pearson")
    }
    
    cor_df <- data.frame(wavenumber = wavenumbers,cor = cor_vec)

    plot_cor <- ggplot(cor_df, aes(x = wavenumber, y = cor)) +
        geom_line(size = 0.3) +
        geom_hline(aes(yintercept = mark1), linetype = "dashed", col = "red") +
        geom_hline(aes(yintercept = mark2), linetype = "dashed", col = "blue") +
        geom_hline(aes(yintercept = -mark1), linetype = "dashed", col = "red") +
        geom_hline(aes(yintercept = -mark2), linetype = "dashed", col = "blue") +
        ggtitle(paste("Correlation by ",group_label, sep = "")) +
        xlab(expression(paste("Wavenumber (cm"^"-1", ")", sep = ""))) +
        ylab("Correlation coefficient") +
        scale_x_continuous(breaks = seq(0, 4000, 500)) +
        theme_bw() +
        theme(
            panel.grid = element_blank(),
            text = element_text(color = "black"),
            axis.title.x = element_text(size = 15),
            axis.title.y = element_text(size = 15),
            axis.text.x = element_text(size = 10),
            axis.text.y = element_text(size = 10),
            axis.ticks.x = element_line(size = 1),
            axis.ticks.y = element_line(size = 1),
            plot.title = element_text(hjust = 0.5, size = 15, face = "bold"),
        )
    
    wave_mark1 <- wavenumbers[abs(cor_vec) > mark1]
    wave_mark2 <- wavenumbers[abs(cor_vec) > mark2]

    return(list(
        plot_cor = plot_cor,
        cor_df = cor_df,
        wave_mark1 = wave_mark1,
        wave_mark2 = wave_mark2
    ))
}
