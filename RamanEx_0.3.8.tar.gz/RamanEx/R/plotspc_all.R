default_theme <- function()
{
  theme_bw()+
  theme(
      panel.grid = element_blank(),
      panel.grid.minor = element_blank(),

      legend.title = element_text(size = 15),
      legend.text = element_text(size = 15),
      legend.background = element_blank(),
      
      text = element_text(color="black"),
      strip.text = element_text(size = 20),
      strip.background = element_rect(fill = "white"),
      
      axis.title= element_text(size=20),
      axis.text = element_text(size = 15),
      axis.ticks = element_line(size = 1),
      axis.ticks.length = unit(0.4,"lines"))
}

###
draw_spc <- function(data,name,color_text = "Drug(μg/mL)",group,color,facet_grid_x,facet_grid_y,weight = 12,height = 4,outpath)
{
  if (facet_grid_x == ".")
  {
    if (facet_grid_y == ".")
    {
      plot_hyperspec1 <- ggplot(data = data,aes(x = wavenumber, y = value,group= {{group}},color={{color}}))+
        #facet_grid( B ~ .,scales = "free")+
        geom_line(size = 1)+ 
        labs(
          x = expression(paste('Wave Number (cm'^{-1},')',sep="")),
          y = "Intensity(a.u.)",
          color = color_text)+
        default_theme()
    }else
    {
      plot_hyperspec1 <- ggplot(data = data,aes(x = wavenumber, y = value,group= {{group}},color={{color}}))+
        facet_grid( . ~ {{facet_grid_y}},scales = "free")+
        geom_line(size = 1)+ 
        labs(
          x = expression(paste('Wave Number (cm'^{-1},')',sep="")),
          y = "Intensity(a.u.)",
          color = color_text)+
        default_theme()
    }
  }else if (facet_grid_y == ".")
  {
    plot_hyperspec1 <- ggplot(data = data,aes(x = wavenumber, y = value,group= {{group}},color={{color}}))+
      facet_grid( {{facet_grid_x}} ~ .,scales = "free")+
      geom_line(size = 1)+ 
      labs(
        x = expression(paste('Wave Number (cm'^{-1},')',sep="")),
        y = "Intensity(a.u.)",
        color = color_text)+
      default_theme()
  }else
  {
    plot_hyperspec1 <- ggplot(data = data,aes(x = wavenumber, y = value,group= {{group}},color={{color}}))+
      facet_grid( {{facet_grid_x}} ~ {{facet_grid_y}},scales = "free")+
      geom_line(size = 1)+ 
      labs(
        x = expression(paste('Wave Number (cm'^{-1},')',sep="")),
        y = "Intensity(a.u.)",
        color = color_text)+
      default_theme()    
  }
  ggsave(filename=paste(outpath,"//",name,"_spc.wmf", sep=""),plot=plot_hyperspec1,
         limitsize=T,width = weight,height = height)
}
