#' Title
#'
#' @param mean_all 
#' @param Pvalue 
#'
#' @return
#' @export
#'
#' @examples
cal_RBCS_selectpeak <- function(mean_all,Pvalue = 0.0001)
{
  diff_result <- sub_mean <- NULL
  
  for (i in levels(factor(mean_all$Group)))
  {
    mean_all_i <- filter(mean_all_test,Group == i)
    for (j in levels(factor(mean_all_i$wavenumber))) {
      mean_all_i_j <- filter(mean_all_i,wavenumber == j)
      control <- filter(mean_all_i_j,RBCS_group == "control")$value
      test <- filter(mean_all_i_j,RBCS_group == "test")$value
      p <- t.test(control,test)$p.value
      if (p > Pvalue) {
        sub_mean_i <- test - control
      }else{sub_mean[i] <- 0}
      sub_mean <- c(sub_mean,sub_mean_i)
    }
    sub_mean <- data.frame(sub_mean)
    rownames(sub_mean) <- levels(factor(mean_all_i$wavenumber))
    sub_mean <- t(sub_mean)
    rownames(sub_mean) <- i
  }
  diff_result <- rbind(diff_result,sub_mean)#
  diff_result[is.na(diff_result)]<-'0'
  return(diff_result)
}

