func_lib <- function() {
# read
    library(data.table)
    library(hyperSpec)
# plot
    library(ggplot2)
    library(ggpubr)
    library(ggtext)
    library(pheatmap)
    library(RColorBrewer)
    library(patchwork)
    library(ggdensity)
# reshape
    library(reshape2)
    library(dplyr)
    library(tidyverse)
    library(rlang)
    library(stringr)
    library(magrittr)
# pretreatment
    library(prospectr)
    library(Rmisc)
# calculation
    library(Rtsne)
    library(e1071)
  # library(ggbiplot)
  # library("MASS")
  # library("lattice")
  # library("mixOmics")
  # library('optparse')
  # library("pROC")
  # library("R.utils")
  # library(xlsx)
  # library("scales")
  # library("pls")
}
