

###tSNE
cal_tSNE <-  function(data,label,dims = 2,perplexity = 500,max_iter = 1000,outpath)
{
  set.seed(50)
  tsne_data <- Rtsne(data, dims = dims, perplexity=perplexity,pca = TRUE,
                     theta=0.3, verbose=TRUE, max_iter = max_iter )
  tsne_frame <- as.data.frame(tsne_data$Y)
  tsne_frame$label <- label
  if(dims == 2)
  { colnames(tsne_frame) <- c("tSNE1","tSNE2","label") }
  return(tsne_frame)
}
