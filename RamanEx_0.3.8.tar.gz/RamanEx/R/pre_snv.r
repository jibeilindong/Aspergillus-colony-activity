#' SNV Normalization
#'
#' @param data_hyperSpec = data_hyperSpec
#' @return a normalized spc as data_hyperSpec object
#' @examples
#' pre_snv(data_hyperspec)
#'
pre_snv <- function(data_hyperSpec) {
  spc <- data_hyperSpec$spc
  spc_snv <- prospectr::standardNormalVariate(spc)
  data_hyperSpec$spc <- spc_snv
  writeLines(paste("snv预处理后共有", length(data_hyperSpec), "条光谱", sep = ""))
  writeLines(paste("波段范围为", min(data_hyperSpec@wavelength), "-", max(data_hyperSpec@wavelength), sep = ""))
  return(data_hyperSpec)
}
