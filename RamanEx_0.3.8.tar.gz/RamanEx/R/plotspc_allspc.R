plot_func_allspc <- function(tb_data,meta)
{
  tb_data <- left_join(select(meta,c("filename","Group","Number")),tb_data,by = "filename")
  hyperspec_melt <- spc_melt(tb_data[,-1],c("Group","Number"),500,3200)
  hyperspec_melt$value <- as.numeric(as.character(hyperspec_melt$value))
  return(hyperspec_melt)
}

plot_allspc <- function(hyperspec_melt_summary,outpath,name, width = 18,height = 18)
{
  plot_hyperspec <- ggplot(data = hyperspec_melt_summary,aes(x = wavenumber, y = value, group = factor(Number))) +
    geom_line(aes(color = factor(Number)),linewidth = 0.8) + facet_wrap(Group~.,scales = "free") + 
    scale_x_continuous(breaks = seq(500,3200,200)) + default_theme() +
    theme(
      legend.position = "none",
      axis.text.x = element_text(size = 15,angle = 45,hjust = 1,vjust = 1),
      axis.text.y = element_blank()) +
    ylab("Normalized Intensity (a.u.)") + 
    xlab(expression(paste('Wavenumber (cm'^{-1},')',sep = "")))
  ggsave(filename=paste(outpath,"//",name,".png", sep=""),
         plot=plot_hyperspec, limitsize=T,width = width,height = height)
}
