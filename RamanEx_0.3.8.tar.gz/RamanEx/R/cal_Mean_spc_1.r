Mean_spc <- function(hyperspec_frame,Name_group)
{
  hyperspec_melt <- reshape2::melt(hyperspec_frame, id.vars = Name_group)
  hyperspec_melt_summary <- summarySE(hyperspec_melt, measurevar = "value", groupvars = c(Name_group,"wavenumber"))
  hyperspec_melt_summary <- select(hyperspec_melt_summary,c(Name_group,"wavenumber","value"))
  return(hyperspec_melt_summary)
}