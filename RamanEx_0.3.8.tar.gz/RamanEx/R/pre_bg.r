#' @title bg
#' @description delete background for each spectra
#' @details 
#' @param hyperSpec_cell cell spec
#' @param hyperSpec_bg bg spec
#' @return A hyperspec
#' @export
#' @import
#' @importFrom
###bg
pre_bg <- function(tb_data,meta)
{
  tb_data_melt <- spc_melt(tb_data,meta_group = "filename",500,3200)
  tb_data_melt_all <- left_join(tb_data_melt,meta[,c("filename","Group")],by = "filename")
  tb_data_melt_all <- data.table(tb_data_melt_all)
  tb_data_melt_1 <- tb_data_melt_all %>% dplyr::group_by(Group,wavenumber) %>%
    dplyr::mutate(diff_value = value - mean(value[grepl("bg",filename)])) %>% 
    dplyr::select(filename,wavenumber,diff_value)

  tb_data_all <- dcast(tb_data_melt_1,filename ~ wavenumber)
  return(tb_data_all)
}

