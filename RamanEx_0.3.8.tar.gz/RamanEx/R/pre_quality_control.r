#' Title
#'
#' @param data_hyperSpec 
#' @param noise_mean 
#' @param noise_sd 
#' @param signal_max 
#'
#' @return
#' @export
#'
#' @examples
#' 
pre_quality_control <- function(spc,spc_reor_filt_qc,
                                noise_mean = 0.03,
                                noise_sd = 0.03,
                                signal_max = 0.1,
                                intensity_min = -5000) {
  
  spc_qc_good <- spc_reor_filt_qc %>% filter(Pre_Noise_mean < noise_mean, Pre_Noise_sd < noise_sd,
                                             Pre_Signal_max > signal_max, Pre_Signal_max < 0.9,
                                             Ori_Intensity_max < 50000,Ori_Intensity_min >= intensity_min) #
  
  spc_good <- spc %>% filter(filename %in% spc_qc_good$filename)
  if(any(duplicated(as.numeric(colnames(spc[,-1])))))
  {
    spc_good_uniq <- unique(spc_good[,c(TRUE,!duplicated(as.numeric(colnames(spc[,-1]))))])
  }else{
    spc_good_uniq <- spc_good
  }
  
  writeLines(paste("输出数据包含", nrow(spc_good_uniq), "条光谱", sep = ""))
  writeLines(paste("去掉光谱共", nrow(spc) - nrow(spc_good_uniq), "条", sep = ""))
  return(spc_good_uniq)
}

pre_quality_control <- function(spc,spc_reor_filt_qc,
                                noise_mean = 0.03,
                                noise_sd = 0.03,
                                signal_max = 0.1,
                                intensity_min = -5000) {
  spc_reor_filt_qc <- spc_reor_filt_qc[!is.na(spc_reor_filt_qc$Pre_Signal_max),]
  spc_reor_filt_qc$inds_1 <- spc_reor_filt_qc$Pre_Noise_mean * 1.3 + 0.1
  spc_qc_good <- spc_reor_filt_qc %>% filter(Ori_Intensity_max < 58000,
                                             Pre_Noise_sd < inds_1, Pre_Noise_mean < 1,
                                             Pre_Signal_max < 1,Pre_Signal_max > 0.1,
                                             Ori_Noise_mean < 40000,
                                             Ori_Intensity_min >= -5000,
                                             Pre_Noise_mean < 0.03, Pre_Noise_sd < 0.03) #
  
  # spc_qc_bad <- spc_reor_filt_qc %>% filter(filename %in% setdiff(spc_reor_filt_qc$filename,spc_qc_good$filename))
  # 

  spc_good <- spc %>% filter(filename %in% spc_qc_good$filename)
  if(any(duplicated(as.numeric(colnames(spc[,-1])))))
  {
    spc_good_uniq <- unique(spc_good[,c(TRUE,!duplicated(as.numeric(colnames(spc[,-1]))))])
  }else{
    spc_good_uniq <- spc_good
  }
  
  writeLines(paste("输出数据包含", nrow(spc_good_uniq), "条光谱", sep = ""))
  writeLines(paste("去掉光谱共", nrow(spc) - nrow(spc_good_uniq), "条", sep = ""))
  return(spc_good_uniq)
}

# dfame <- data.frame(spc_reor_filt_qc[!is.na(spc_reor_filt_qc$Pre_Signal_max),c(8,2)])
# 
# dfame$Pre_Signal_max[which(dfame$Pre_Signal_max > 2 )] <- NA
# dfame <- dfame[!is.na(dfame$Pre_Signal_max),]
# dfame$Pre_Signal_max <- 100 * dfame$Pre_Signal_max / max(dfame$Pre_Signal_max)
# dfame$Ori_Noise_mean <- 100 * dfame$Ori_Noise_mean / max(dfame$Ori_Noise_mean)
# 
# 
# library(fpc)
# db1 <- dbscan(dfame,eps = 3)
# plot(db1, dfame)
