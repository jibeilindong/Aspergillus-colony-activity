#' Initialization of working dictory and creat the outpath
#'
#' @param working_dir working dictory
#' @param output_folder output folder name as a character vector object
#' @return the outpath
#' @examples
#' outpath <- func_initialization(working_dir, output_folder = "output")
#' working_dir <- "F:/qibebt/HP/HP_ori"
func_initialization <- function(working_dir, output_folder = "output") {
  outpath <- paste(working_dir, "/", output_folder, sep = "")
  setwd(working_dir)
  dir.create(outpath)
  writeLines(paste("输出路径是: ", outpath, sep = ""))
  return(outpath)
}
