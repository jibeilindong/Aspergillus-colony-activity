read_3data <- function(folderpath){
  all_spc <- fread(paste(folderpath,"/alldata_spc.txt.gz",sep = ""), header = TRUE, sep = "\t")
  all_meta <- fread(paste(folderpath,"/alldata_meta.txt",sep = ""), header = TRUE, sep = "\t")
  data_info <- fread(paste(folderpath,"/data_info.txt",sep = ""), header = TRUE, sep = "\t")
  #all_spc_ori <- read_rescale(all_spc,15000)
  
  return(list(all_spc,all_meta,data_info))
}
