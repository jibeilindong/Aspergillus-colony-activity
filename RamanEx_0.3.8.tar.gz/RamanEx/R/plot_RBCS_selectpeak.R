plot_RBCS_selectpeak <- function(spc_mean_df,wave_num,outpath,foldername = "peaks_concentration")
{
  waves_sel_df<-as.numeric(wave_num)
  group_name = "Group"
  peak_concentration_folder <- func_initialization(outpath, foldername)
  peakpath <- peak_concentration_folder
  dpi = 800
  
  for(i in levels(factor(spc_mean_df[,1])))
  {
    spc_mean_level_df <- data.frame(wavenumber = as.numeric(names(spc_mean_df)[-1]),
                                    intensity = as.numeric(spc_mean_df[which(spc_mean_df[,1] == i), -1]))
    
    spc_mean_level_df$intensity_sel <- spc_mean_level_df$intensity
    if (is.na(sum(waves_sel_df))) {
      next
    }
    logic <- spc_mean_level_df$wavenumber %in% waves_sel_df
    spc_mean_level_df$intensity_sel[logic == FALSE] <- NA
    
    plot_sel <- ggplot(spc_mean_level_df, aes(x = wavenumber, y = intensity)) +
      geom_point(aes(x = wavenumber, y = intensity_sel),color = "black",fill = "red",shape = 21,alpha = 0.8,size = 2.5) +
      geom_line() +
      ggtitle(paste(group_name, " = ", i, sep = "")) +
      xlab(expression(paste("Wavenumber (cm"^"-1", ")", sep = ""))) +
      ylab("Normalized Intensity (a.u.)") +
      scale_x_continuous(breaks = seq(0, 4000, 500)) +
      theme_bw() +
      theme(
        panel.grid = element_blank(),
        text = element_text(color = "black"),
        plot.title = element_text(hjust = 0.5, size = 15, face = "bold"),
        axis.title.x = element_text(size = 15),
        axis.title.y = element_text(size = 15),
        axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        axis.ticks.x = element_line(size = 1),
        axis.ticks.y = element_line(size = 1))
    
    peaks <- c()
    for (wave in waves_sel_df) {
      wave_ind <- which.min(abs(spc_mean_level_df$wavenumber - wave))
      if (wave_ind == 1 || wave_ind == length(spc_mean_level_df$wavenumber)) {
        next
      } else if (spc_mean_level_df$intensity[wave_ind] > spc_mean_level_df$intensity[wave_ind + 1] &
                 spc_mean_level_df$intensity[wave_ind] > spc_mean_level_df$intensity[wave_ind - 1]
      ) {peaks <- c(peaks, wave)}
    }
    
    ggsave(filename = paste(peakpath, "/", i, "_meanspc.png", sep = ""),plot_sel,width = 10, height = 10, dpi = dpi)
    write.table(peaks,file = paste(peakpath, "/", "peaks_", i, sep = ""),row.names = FALSE,col.names = FALSE)
  }
  
}

