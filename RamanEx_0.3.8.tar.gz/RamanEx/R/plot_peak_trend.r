plot_peak_trend <- function(spc_mean_df, group_same, group_diff, peakpath, trendpath, dpi = 800) {
    filenames <- list.files(peakpath, pattern = ".txt", full.names = TRUE)
    for (i in 1:length(filenames)) {
        filename_split <- unlist(strsplit(basename(filenames[i]), "_"))
        mark <- as.numeric(filename_split[2])
        level <- as.numeric(str_extract_all(filename_split[3], "\\d+"))
        if (file.info(filenames[i])$size == 0) {
            next
        }
        peaks_sel_df <- read.table(filenames[i], , sep = "\t", header = FALSE)
        peaks <- as.character(peaks_sel_df$V1)
        for (peak in peaks) {
            if (as.numeric(peak) < 1800) {
                peak_trend <- spc_mean_df[spc_mean_df[group_same] == level, c(group_diff, peak)]
                names(peak_trend)[2] <- "intensity"
                plot_trend <- ggplot(peak_trend, aes_string(x = group_diff, y = "intensity")) +
                    geom_point() +
                    geom_line() +
                    ggtitle(paste("mark =", mark, "\n",
                        group_same, "=", level, "\n",
                        "peak =", peak, " cm", "-1",
                        sep = ""
                    )) +
                    xlab(group_diff) +
                    ylab("Normalized Intensity (a.u.)") +
                    theme_bw() +
                    theme(
                        panel.grid = element_blank(),
                        text = element_text(color = "black"),
                        plot.title = element_text(hjust = 0.5, size = 15, face = "bold"),
                        axis.title.x = element_text(size = 15),
                        axis.title.y = element_text(size = 15),
                        axis.text.x = element_text(size = 10),
                        axis.text.y = element_text(size = 10),
                        axis.ticks.x = element_line(size = 1),
                        axis.ticks.y = element_line(size = 1)
                    )
                ggsave(
                    filename = paste(trendpath, "/", mark, "_", level, "_", peak, ".png", sep = ""),
                    plot_trend,
                    width = 10, height = 10, dpi = dpi
                )
            }
        }
    }
}
