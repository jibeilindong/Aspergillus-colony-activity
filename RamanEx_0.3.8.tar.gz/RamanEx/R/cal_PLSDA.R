

PLSDA <- function(data,label)
{
  plsda.res <- plsda(data, label, ncomp = 20) 
  plotIndiv(plsda.res, ind.names = F, legend = TRUE, ellipse = TRUE,title = 'PLS-DA')
  return(plsda.res) 
}
###plsda_plot
plsda_plot <- function(plsda_data,name,label)
{
  plsda_data_variates<- plsda_data$variates[[1]]
  plsda_data_variates <- data.frame(plsda_data_variates)
  plsda_data_variates <- cbind(label,plsda_data_variates)
  windowsFonts(myFont = windowsFont("Times New Roman"))
  plot1  <- ggplot(plsda_data_variates,aes(comp1,comp2,color=label)) +
    geom_point()+ stat_ellipse(level = 0.8)+
    default_theme()
  return(plot1)
}