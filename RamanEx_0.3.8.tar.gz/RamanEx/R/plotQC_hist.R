plot_hist <- function(tb_i,group,xintercept,xlab)
{
  plot<-ggplot(tb_i,aes(x={{group}}))+
    geom_density(aes(y = ..ndensity..),alpha = 0.4) + 
    geom_histogram(aes(y = ..ncount..),bins = 1000) + 
    geom_vline(aes(xintercept=xintercept), colour="red", linetype="dashed",size = 0.2)+
    default_theme() +
    theme(
      legend.position = "none",
      axis.text.x = element_text(size = 10,angle = 45,vjust = 1,hjust = 1))+
    xlab(xlab)+
    ylab('Density')
  return(plot)
}
