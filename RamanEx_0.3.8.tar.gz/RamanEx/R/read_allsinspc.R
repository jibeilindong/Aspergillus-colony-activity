#' Read all txt files(single spc) in every subfolder of working directory
#'
#' @param folderpath the working directory
#' @return a dataframe with a filenames and all data
#' @export
#'
#' @examples
#' folderpath <- "F:/qibebt/HP/HP_ori"
#' Name_group <- c("A", "B", "group_concentration", "group_time")
#' data_hyperSpec <- read_sin2hs(folderpath, Name_group)
read_allsinspc <- function(folderpath, Name_group, outpath,instrument ="CAST-R") {
  if(instrument == "FlowRACS_1"){
    # 获取路径下所有文件夹内txt的地址信息
    foldernames <- list.files(folderpath, full.names = TRUE)
    filepaths <- c()
    for (foldername in foldernames) {
      filepaths_tem <- list.files(paste(foldername,"/cellSort/waveNumTxts/subbackground/",sep = ""), pattern = "*.txt", full.names = TRUE)
      filepaths <- c(filepaths, filepaths_tem)
    }
    filenames <- gsub(".txt", "", basename(filepaths))
  }else if(instrument == "RACSseq_1"){
    # 获取路径下所有文件夹内txt的地址信息
    foldernames <- list.files(folderpath, full.names = TRUE)
    filepaths <- c()
    for (foldername in foldernames) {
      filepaths_tem <- list.files(paste(foldername,"/freeCheck/waveNumTxts/",sep = ""), pattern = "*.txt", full.names = TRUE)
      filepaths <- c(filepaths, filepaths_tem)
    }
    filenames <- gsub(".txt", "", basename(filepaths))
  }else{
    # 获取路径下所有文件夹内txt的地址信息
    foldernames <- list.files(folderpath, full.names = TRUE)
    filepaths <- c()
    for (foldername in foldernames) {
      filepaths_tem <- list.files(foldername, pattern = "*.txt", full.names = TRUE)
      filepaths <- c(filepaths, filepaths_tem)
    }
    filenames <- gsub(".txt", "", basename(filepaths))
  }
  inds_duplicated_filename <- which(duplicated(filenames) == TRUE)
  if(length(inds_duplicated_filename) != 0 ){
    print(paste("There are",length(inds_duplicated_filename),"duplicated files！/n it's ",inds_duplicated_filename,sep = " "))
  }else{
    # 根据文件地址读取数据，并整理成一个table
    if (instrument == "Renishaw") {
      spc_data <- c()
      for (i in 1:length(filenames)) {
        spc_data_i <- fread(filepaths[i], header = FALSE, sep = "\t")
        spc_data_i$filepath <- paste(gsub(".txt", "", basename(filenames[i])),spc_data_i$V1,spc_data_i$V2,sep = "_")
        spc_data_i$group_name <- gsub(".txt", "", basename(filenames[i]))
        spc_data <- rbind(spc_data,spc_data_i[,3:6])
      }
      spc_data <- data.table(spc_data)
      colnames(spc_data) <- c("wavenumber","value","filename","group_name")
    }else {
      spc_data <- matrix(data = NA, nrow = length(filenames) * 6000, ncol = 3)
      num_row_up <- num_row_down <- 0
      for (i in 1:length(filenames)) {
        spc_data_i <- fread(filepaths[i], header = FALSE, sep = "\t")
        spc_data_i$filepath <- gsub(".txt", "", basename(filenames[i]))
        num_row_up <- num_row_down + 1
        num_row_down <- num_row_up + nrow(spc_data_i) - 1 
        spc_data[num_row_up:num_row_down,] <- as.matrix(spc_data_i)
      }
      spc_data <- data.table(spc_data[1:num_row_down,])
      colnames(spc_data) <- c("wavenumber","value","filename")
      spc_data$group_name <- spc_data$filename
    }
    
    # 统计光谱信息
    meta_data_wavenumber <- spc_data %>% 
      group_by(filename,group_name) %>%
      dplyr::summarise(wavenum = n(),max_wave = max(wavenumber),min_wave = min(wavenumber))
    
    # 统计meta信息
    meta_data <- as.data.frame(tstrsplit(filenames, "_"),col.names = Name_group)
    col_1 <- rlang::syms(colnames(dplyr::select(meta_data,starts_with("group"))))
    meta_data <- meta_data %>% 
      dplyr::mutate(Group = paste(!!!col_1,sep = "_")) %>%
      dplyr::mutate(group_name = filenames) %>%
      dplyr::arrange(Group) %>%
      dplyr::select("group_name",starts_with("group"))
    meta_data <- left_join(meta_data, meta_data_wavenumber,by = "group_name")
    meta_data <- meta_data %>% 
      dplyr::mutate(Number = c(1:length(filename))) 
    
    # 汇总信息
    meta_all <- meta_data %>% 
      group_by(Group,wavenum) %>%
      dplyr::summarise(spcnum = n())
    
    # spc_data_new <- read_scale(spc_data[,1:3],15000)
    
    # 输出文件
    outpath_files <- func_initialization(outpath, output_folder = "files")
    
    fwrite(meta_data,paste(outpath_files,"/alldata_meta",".txt",sep=""),
           row.names=F,col.names=T,quote=F,sep = "\t")  
    fwrite(spc_data,paste(outpath_files,"/alldata_spc",".txt.gz",sep=""),
           row.names=F,col.names=T,quote=F,sep = "\t")
    fwrite(meta_all,paste(outpath_files,"/data_info",".txt",sep=""),
           row.names=F,col.names=T,quote=F,sep = "\t")
    
    # 展示基本信息
    writeLines(paste("输出数据包含", length(filenames), "条光谱。", sep = ""))
    writeLines(paste("其中包含", length(levels(factor(meta_data$Group))), "个组:", sep = ""))
    print(levels(factor(meta_data$Group)))
  }
}
