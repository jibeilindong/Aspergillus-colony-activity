#' Title
#'
#' @param used_packages 
#'
#' @return
#' @export
#'
#' @examples
func_pkgs_install <- function(used_packages = c(
                        "data.table",
                        "hyperSpec",
                        "ggplot2",
                        "ggpubr",
                        "reshape2",
                        "dplyr",
                        "ggdensity",
                        "stringr",
                        "prospectr",
                        "patchwork",
                        "lattice",
                        "RColorBrewer",
                        "optparse",
                        "pROC",
                        "R.utils",
                        "rlang",
                        "tidyverse",
                        "scales",
                        "Rtsne",
                        "pls",
                        "e1071",
                        "ggtext",
                        "prospectr",
                        "devtools",
                        "Rmisc",
                        "pheatmap"
                      )) {
  installed_packages <- library()$results[, 1]
  uninstalled_packages <- setdiff(used_packages, installed_packages)
  for (i in uninstalled_packages) {
    if (i != "ggbiplot") {
      install.packages(i)
    } else if ("devtools" %in% installed_packages) {
      library(devtools)
      install_github("vqv/ggbiplot", force = TRUE)
    } else {
      install.packages("devtools")
      library(devtools)
      install_github("vqv/ggbiplot", force = TRUE)
      uninstalled_packages <- setdiff(uninstalled_packages, "devtools")
    }
  }

  for (i in used_packages) {
    library(i, character.only = TRUE)
  }

}
