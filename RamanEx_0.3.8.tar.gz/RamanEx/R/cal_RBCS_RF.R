RBCS_RF <- function(data_hyperSpec,group,outfolder = "RF_imps", alpha = 0.0001, ntree=1000, errortype = 'oob', verbose=FALSE, nfolds=3, rf.cv=FALSE)
{
  x<-data_hyperSpec$spc
  y<-data_hyperSpec$Group
  
  #--------------------------------------------------
  # Out-of-bag classification in traing data and prediction in test data
  #--------------------------------------------------
  y<-as.factor(y)
  oob.result <- rf.out.of.bag(x, y, verbose=verbose, ntree=ntree)
  
  #--------------------------------------------------
  #   RF importances of features
  #--------------------------------------------------
  dir.create(paste(outpath, outfolder, sep = "/"))
  
  imps<-oob.result$importances
  imps<-imps[order(imps,decreasing = TRUE)]
  imps.cutoff<-imps[which(imps>0.002)]
  sink(paste(outpath,"/",outfolder,"/RBCS_imps",group,"_All_sorted.xls",sep=""));cat("\t");write.table(imps,quote=FALSE,sep="\t");sink()
  sink(paste(outpath,"/",outfolder,"/RBCS_imps",group,"_cutoff_sorted.xls",sep=""));cat("\t");write.table(imps.cutoff,quote=FALSE,sep="\t");sink()
  
  return(imps.cutoff)
}
