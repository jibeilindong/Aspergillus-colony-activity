#' Title
#'
#' @param data_hyperSpec 
#' @param m 
#' @param p 
#' @param w 
#' @param delta.wav 
#'
#' @return
#' @export
#'
#' @examples
pre_sg <- function(spc, m = 0, p = 5, w = 7, delta.wav = 2) {
  spc_sg <- cbind(spc[, 1:((w - 1) / 2)],
                  prospectr::savitzkyGolay(spc,m = m,p = p,w = w,delta.wav = 2),
                  spc[, (ncol(spc) - (w - 1) / 2 + 1):ncol(spc)])
  return(spc_sg)
}
