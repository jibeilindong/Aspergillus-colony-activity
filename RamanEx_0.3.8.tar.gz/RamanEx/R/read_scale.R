read_scale <- function(spc_data,block_size = 15000){
  num_rows <- nrow(spc_data)
  num_blocks <- ceiling(num_rows / block_size)
  
  # 创建新数据框，用 NA 填充
  spc_data_new <- matrix(NA, nrow = block_size, ncol = 3 * num_blocks)
  
  # 将原数据框按块大小分割并填充到新数据框中
  for (i in 1:num_blocks) {
    start_row <- (i-1)*block_size+1
    end_row <- min(i*block_size, num_rows)
    start_col <- (i-1)*3+1
    end_col <- i*3
    if(i == num_blocks & num_rows / block_size < num_blocks){
      spc_data_new[1:length(start_row:end_row), start_col:end_col] <- as.matrix(spc_data[start_row:end_row, 1:3])
    }else(
      spc_data_new[1:block_size, start_col:end_col] <- as.matrix(spc_data[start_row:end_row, 1:3])
    )
    
  }
  return(spc_data_new)
}

read_rescale <- function(spc_data_new,block_size = 15000){
  num_col <- ncol(spc_data_new) / 3
  inds <- as.numeric(base::table(is.na(spc_data_new[,ncol(spc_data_new)]))[1])
  num_rows <- (num_col-1) * block_size + inds
  
  # 创建新数据框，用 NA 填充
  spc_data_ori <- base::matrix(NA, nrow = num_rows, ncol = 3)
  
  # 将原数据框按块大小分割并填充到新数据框中
  for (i in 1:num_col) {
    start_row <- (i-1)*block_size+1
    end_row <- min(i*block_size, num_rows)
    start_col <- (i-1)*3+1
    end_col <- i*3
    
    if(i == num_col){
      spc_data_ori[start_row:end_row,] <- as.matrix(spc_data_new[1:inds,start_col:end_col])
    }else(
      spc_data_ori[start_row:end_row,] <- as.matrix(spc_data_new[1:block_size,start_col:end_col])
    )
  }
  all_spc_ori <- as.data.frame(spc_data_ori)
  colnames(all_spc_ori) <- c("wavenumber","value","filename")
  all_spc_ori$value <- as.numeric(as.character(all_spc_ori$value))
  return(all_spc_ori)
}
