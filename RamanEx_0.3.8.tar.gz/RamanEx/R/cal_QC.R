cal_QC <- function(spc, norm_method = "max") {
  spc_ori <- spc
  wavenumber <- as.numeric(colnames(spc_ori[,-1]))
  
  spc_baseline <- pre_baseline(spc_ori, 1)
  #spc_baseline_sg <- pre_sg(spc_baseline)
  if(max(wavenumber) > 3050)
  {
    CH_part <- spc_waveumber(spc_ori[,-1],2700,3050)
    spc_new <- pre_norm(spc_baseline,2700,3050,norm_method)
  }else{
    CH_part <- spc_waveumber(spc_ori[,-1],600,1730)
    spc_new <- pre_norm(spc_baseline,
      from = min(wavenumber),
      to = max(wavenumber),
      method = norm_method
    )
  }
  #spc_new <- pre_spike_matrix(spc_new)
  Noise_part <- cbind(
    spc_waveumber(spc_new[,-1], 1780, 2000),
    spc_waveumber(spc_new[,-1], 2350, 2650)
  )
  Noise_ori <- cbind(
    spc_waveumber(spc_ori[,-1], 1780, 2000),
    spc_waveumber(spc_ori[,-1], 2350, 2650)
  )
  Signal_part <- spc_waveumber(spc_new[,-1], 600, 1730)
  
  if (!is.null(dim(Signal_part))) {
    spc_QC <- data.frame(
      filename = spc$filename,
      Ori_Noise_mean =  apply(abs(Noise_ori), 1, mean),
      Ori_Intensity_mean = apply(spc_ori[,-1], 1, mean),
      Ori_Intensity_min = apply(spc_ori[,-1], 1, min),
      Ori_Intensity_max = apply(CH_part, 1, max),
      Pre_Noise_mean = apply(abs(Noise_part), 1, mean),
      Pre_Noise_sd = apply(Noise_part, 1, sd),
      Pre_Signal_max = apply(abs(Signal_part), 1, max)
    )
  } else {
    spc_QC <- data.frame(
      filename = spc$filename,
      Ori_Noise_mean =  mean(abs(Noise_ori)),
      Ori_Intensity_mean = mean(spc_ori),
      Ori_Intensity_min = min(spc_ori),
      Ori_Intensity_max = max(CH_part),
      Pre_Noise_mean = mean(abs(Noise_part)),
      Pre_Noise_sd = sd(Noise_part),
      Pre_Signal_max = max(abs(Signal_part))
    )
  }
  return(spc_QC)
}
