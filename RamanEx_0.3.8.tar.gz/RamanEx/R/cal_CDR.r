#' Title
#'
#' @param hyperspec a spec as hyperspec object
#'
#' @return a dataframe consist with all groups and C-D ratio values
#' @export
#'
#' @examples
#' CD_group <- CD_ratio(data_baseline_normalization)
cal_CDR <- function(spc,meta)
{
  hs_data_frame <- as.data.frame(spc)
  wave_nums <- as.numeric(as.character(colnames(hs_data_frame[,-1])))
  
  if(any(duplicated(wave_nums))== TRUE)
  {
    hs_data_frame <- hs_data_frame[, -max(which(duplicated(wave_nums)))]
    wave_nums <- wave_nums[-max(which(duplicated(wave_nums)))]
  }
  
  CD_ranges <- hs_data_frame[,which.min(abs(wave_nums - 2050)):which.min(abs(wave_nums - 2300))]
  CH_ranges <- hs_data_frame[,which.min(abs(wave_nums - 2800)):which.min(abs(wave_nums - 3050))]
  PA_ranges <- hs_data_frame[,which.min(abs(wave_nums - 1550)):which.min(abs(wave_nums - 1600))]
  PB_ranges <- hs_data_frame[,which.min(abs(wave_nums - 1640)):which.min(abs(wave_nums - 1690))]
  X_ranges <- hs_data_frame[,which.min(abs(wave_nums - 2895)):which.min(abs(wave_nums - 2915))]
  CD_ratio_groups <- hs_data_frame %>% 
    mutate( CD_range = rowSums(CD_ranges)) %>% 
    mutate( CH_range = rowSums(CH_ranges)) %>% 
    mutate( P_range = rowSums(PA_ranges) + rowSums(PB_ranges)) %>% 
    mutate( X_range = rowSums(X_ranges)) %>% 
    mutate( CD_ratio = rowSums(CD_ranges)/(rowSums(CD_ranges)+rowSums(CH_ranges))) %>% 
    select(filename, CD_range,CH_range,P_range,X_range,CD_ratio)
  CD_ratio_groups <- left_join(CD_ratio_groups,meta,by = "filename")
  return(CD_ratio_groups)
}

cal_index <- function(spc,meta)
{
  hs_data_frame <- as.data.frame(spc)
  wave_nums <- as.numeric(as.character(colnames(hs_data_frame[,-1])))
  
  if(any(duplicated(wave_nums))== TRUE)
  {
    hs_data_frame <- hs_data_frame[, -max(which(duplicated(wave_nums)))]
    wave_nums <- wave_nums[-max(which(duplicated(wave_nums)))]
  }
  
  CH_ranges <- hs_data_frame[,which.min(abs(wave_nums - 2800)):which.min(abs(wave_nums - 3050))]
  Oil_A <- hs_data_frame[,which.min(abs(wave_nums - 2840))]
  Oil_B <- hs_data_frame[,(which.min(abs(wave_nums - 2850))-2):(which.min(abs(wave_nums - 2850))+2)]
  DU_A <- hs_data_frame[,(which.min(abs(wave_nums - 1440))-2):(which.min(abs(wave_nums - 1440))+2)]
  DU_B <- hs_data_frame[,(which.min(abs(wave_nums - 1670))-2):(which.min(abs(wave_nums - 1650))+2)]
  DU_C <- hs_data_frame[,(which.min(abs(wave_nums - 1800))-2):(which.min(abs(wave_nums - 1800))+2)]
  
  CD_ratio_groups <- hs_data_frame %>% 
    mutate( Oil_index = apply(Oil_B,1,max)) %>% 
    mutate( DU_A = rowSums(DU_A)) %>% 
    mutate( DU_B = rowSums(DU_B)) %>% 
    mutate( DU_C = rowSums(DU_C)) %>%
    mutate( Index = (DU_B - DU_C)/(DU_A - DU_C) ) %>%
    select(filename, Oil_index,DU_A,DU_B,DU_C,Index)
  CD_ratio_groups <- left_join(CD_ratio_groups,meta,by = "filename")
  return(CD_ratio_groups)
}
