find_wave2peak <- function(spc_mean_df, group_name, wavepath, peakpath, dpi = 800) {
    filenames <- list.files(wavepath, pattern = ".txt", full.names = TRUE)
    filenames <- filenames[str_starts(basename(filenames),"0.6")]
    for (i in 1:length(filenames)) {
        filename_split <- unlist(strsplit(basename(filenames[i]), "_"))
        mark <- as.numeric(filename_split[1])
        level <- as.numeric(str_extract_all(filename_split[2], "\\d+"))
        group_ind <- grep(pattern = "group", names(spc_mean_df))
        spc_mean_level_df <- spc_mean_df[spc_mean_df[group_name] == level, -(1:2)]
        spc_mean_level_df <- melt(spc_mean_level_df,id.vars = "group_concentration",variable.name = "wavenumber",value.name = "intensity")
        spc_mean_level_df$wavenumber <- as.numeric(as.character(spc_mean_level_df$wavenumber))
        spc_mean_level_df$intensity_sel <- spc_mean_level_df$intensity
        waves_sel_df <- read.table(filenames[i], sep = "\t", header = FALSE)
        if (is.na(sum(waves_sel_df$V1))) {
            next
        }
        logic <- spc_mean_level_df$wavenumber %in% waves_sel_df$V1
        spc_mean_level_df$intensity_sel[logic == FALSE] <- NA

        plot_sel <- ggplot(spc_mean_level_df, aes(x = wavenumber, y = intensity)) +
          geom_line(aes(group = group_concentration)) +  
          geom_point(aes(x = wavenumber, y = intensity_sel),
                colour = "grey90",
                fill = "red",
                shape = 21,
                alpha = 0.8,
                size = 0.5
            ) +
            ggtitle(paste(group_name, " = ", level, "\nmark = ", mark, sep = "")) +
            xlab(expression(paste("Wavenumber (cm"^"-1", ")", sep = ""))) +
            ylab("Normalized Intensity (a.u.)") +
            scale_x_continuous(breaks = seq(0, 4000, 200)) +
            theme_bw() +
            theme(
                panel.grid = element_blank(),
                text = element_text(color = "black"),
                plot.title = element_text(hjust = 0.5, size = 15, face = "bold"),
                axis.title.x = element_text(size = 15),
                axis.title.y = element_text(size = 15),
                axis.text.x = element_text(size = 10),
                axis.text.y = element_text(size = 10),
                axis.ticks.x = element_line(size = 1),
                axis.ticks.y = element_line(size = 1)
            )
        #plot_sel
        peaks <- c()
        for (wave in waves_sel_df$V1) {
            wave_ind <- which.min(abs(spc_mean_level_df$wavenumber - wave))
            if (wave_ind == 1 || wave_ind == length(spc_mean_level_df$wavenumber)) {
                next
            } else if (spc_mean_level_df$intensity[wave_ind] > spc_mean_level_df$intensity[wave_ind + 1] &
                spc_mean_level_df$intensity[wave_ind] > spc_mean_level_df$intensity[wave_ind - 1]
            ) {
                peaks <- c(peaks, wave)
            }
        }

        ggsave(
            filename = paste(peakpath, "/", mark, "_", level, ".png", sep = ""),
            plot_sel,
            width = 10, height = 10, dpi = dpi
        )
        write.table(peaks,
            file = paste(peakpath, "/", "peaks_", basename(filenames[i]), sep = ""),
            row.names = FALSE,
            col.names = FALSE
        )
    }
}
