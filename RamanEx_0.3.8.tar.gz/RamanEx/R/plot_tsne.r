plot_tsne <- function(tSNE_data,level = 0.8)
{
  plot <- ggplot(tSNE_data,aes(tSNE1,tSNE2,color = as.factor(label)))+ 
    geom_point() + stat_ellipse(level = level)+
    default_theme()
  return(plot)
}
