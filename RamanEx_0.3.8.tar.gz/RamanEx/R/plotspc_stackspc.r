plot_func_spcgroup <- function(tb_data,meta,labels = c("Group"))
{
  tb_data <- left_join(meta,tb_data,by = "filename")
  hyperspec_melt <- spc_melt(tb_data,labels,500,3200)
  hyperspec_melt$value <- as.numeric(as.character(hyperspec_melt$value))
  hyperspec_melt_summary <- Rmisc::summarySE(hyperspec_melt, measurevar = "value", groupvars = c(labels,"wavenumber"))
  return(hyperspec_melt_summary)
}

plot_Meanspc <- function(melt_summary,stack_height = 0.05,outpath,name,width = 18,height = 18)
{
  levels <- levels(factor(melt_summary$Group))
  n <- length(levels) * stack_height
  for(i in levels)
  {
    inds <- which(melt_summary$Group == i )
    melt_summary[inds,]$value <- melt_summary[inds,]$value + n
    n <- n - stack_height
  }
  
  plot_hyperspec <- ggplot(data = melt_summary,aes(x = wavenumber, y = value, group = factor(Group))) +
    geom_ribbon(aes(ymin = value - sd, ymax = value + sd, fill = factor(Group)),alpha = 0.3) +
    geom_line(aes(color = factor(Group)),size = 0.8) + 
    scale_x_continuous(breaks = seq(500,3200,200)) +
    default_theme()+
    theme(
      axis.text.x = element_text(size = 15,angle = 45,hjust = 1,vjust = 1),
      axis.text.y = element_blank(),
      axis.ticks.y = element_blank()) +
    ylab("Normalized Intensity (a.u.)") +
    xlab(expression(paste('Wavenumber (cm'^{-1},')',sep = "")))
  ggsave(filename=paste(outpath,"//",name,".pdf", sep=""),
         plot=plot_hyperspec, limitsize=T,width = width,height = height)
  return(plot_hyperspec)
}
