cal_cor_bygroup <- function(spc_mean_df, group_same, group_diff, mark1, mark2) {
    group_levels <- as.numeric(unlist(unique(spc_mean_df[group_same])))
    wavenumbers <- as.numeric(names(spc_mean_df)[-grep(pattern = "group", names(spc_mean_df))])

    cor_mat <- matrix(NA,length(wavenumbers),length(group_levels),dimnames = list(wavenumbers, group_levels))
    plot_list <- mark1_list <- mark2_list <- list()

    for (i in 1:length(group_levels)) {
        spc_mean_df_level <- spc_mean_df[spc_mean_df[group_same] == group_levels[i], ]
        
        cor_list <- cal_cor(spc_mean_df_level, group_diff, mark1, mark2)
        ind <- as.character(group_levels[i])
        plot_list[[ind]] <- cor_list$plot_cor +
            ggtitle(paste(group_same, " = ", group_levels[i], sep = "")) +
            theme(
                axis.title.x = element_text(size = 10),
                axis.title.y = element_text(size = 10),
                axis.text.x = element_text(size = 7),
                axis.text.y = element_text(size = 7),
                plot.title = element_text(hjust = 0.5, size = 10, face = "bold"),
            )

        cor_mat[, i] <- cor_list$cor_df$cor
        mark1_list[[ind]] <- cor_list$wave_mark1
        mark2_list[[ind]] <- cor_list$wave_mark2
    }

    plot <- ggarrange(
        plotlist = plot_list,
        nrow = (length(group_levels) + 1) %/% 2,
        ncol = 2
    )

    return(list(
        plot = plot,
        cor_mat = cor_mat,
        mark1_list = mark1_list,
        mark2_list = mark2_list
    ))
}
