plot_RBCS_heatmap <- function(hyperspec_melt,wave_num,outpath,name)
{
  myPal <- colorRampPalette(c("white","blue","yellow","red"))(n=200)
  
  hyperspec_diff_melt <- data.frame(t(hyperspec_melt[,-c(1:4)]))
  hyperspec_diff_melt<-cbind(rownames(hyperspec_diff_melt),hyperspec_diff_melt)
  colnames(hyperspec_diff_melt) <- c("wavenumber",paste(hyperspec_melt$group_strain,hyperspec_melt$group_conc,sep = "_"))
  
  hyperspec_diff_melt <- filter(hyperspec_diff_melt,wavenumber %in% wave_num)
  rawdata_new<-data.frame(lapply(hyperspec_diff_melt,function(x) as.numeric(x)),row.names = T,check.names = F)
  rawdata_new <- t(rawdata_new)
  p <- pheatmap(rawdata_new,cluster_rows =F, cluster_cols = F,color=myPal,
                fontsize=10,fontsize_col=5,cutree_col=FALSE,angle_col = "45",
                cellwidth = 10,cellheight = 10,bg="white")
  ggsave(paste(outpath,"/",name,"_heatmap_result.png",sep=''),p,width = 28,height = 10,limitsize = FALSE)
}
