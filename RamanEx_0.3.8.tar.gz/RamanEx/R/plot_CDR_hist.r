#' Title
#'
#' @param CD_ratio_groups 
#'
#' @return
#' @export
#'
#' @examples
plot_CDR_hist <- function(CD_ratio_groups)
{
  hist_CDR_plot <-
    ggplot(CD_ratio_groups, aes(x = CD_ratio, fill = factor(Group))) +
    geom_density(alpha = 0.4) + facet_grid(Group ~ .) +
    default_theme() +
    theme(
      legend.position = "none",
      axis.text.x = element_text(size = 15, angle = 45,hjust = 1,vjust = 1)) +
    xlab('Metabolic activity (CD-ratio)')
  return(hist_CDR_plot)
}