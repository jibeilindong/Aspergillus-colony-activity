cal_meta_group <- function(hs_meta_1,hs_meta_2){
  
  hs_meta_1 <- hs_meta_1 %>% dplyr::group_by(Group) %>% 
    dplyr::mutate(Num = n()) %>% dplyr::select(Group,Num) %>% unique()
  hs_meta_2 <- hs_meta_2 %>% dplyr::group_by(Group) %>% 
    dplyr::mutate(Num = n()) %>% dplyr::select(Group,Num) %>% unique()
  
  colnames(hs_meta_1) <- c("Group","Num_ori")
  colnames(hs_meta_2) <- c("Group","Num_QC")
  
  hs_meta_group <- left_join(hs_meta_1,hs_meta_2,by = "Group") %>% 
    mutate(QC_ratio =round( Num_QC/Num_ori * 100, digits = 2))
    
  
  return(hs_meta_group)
}
