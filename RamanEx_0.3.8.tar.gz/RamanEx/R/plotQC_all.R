plotQC_hist <- function(tb_i,group,xintercept,xlab)
{
  plot<-ggplot(tb_i,aes(x={{group}}))+
    geom_density(aes(y = ..ndensity..),alpha = 0.4) + 
    geom_histogram(aes(y = ..ncount..),bins = 1000) + 
    geom_vline(aes(xintercept=xintercept), colour="red", linetype="dashed",size = 0.2)+
    scale_x_continuous(limits = c(40000,65500))+
    default_theme() +
    theme(
      legend.position = "none",
      axis.text.x = element_text(size = 10,angle = 45,vjust = 1,hjust = 1))+
    xlab(xlab)+
    ylab('Density')
  return(plot)
}

plot_QC <- function(spc_reor_filt_qc,outpath,name,
                    A = 0.03,B = 0.03,C = 0.1,
                    D = 200, E = 15, F = 65500){
  #plot QC 多个指标 Noise_mean；Noise_sd；Signal_max；Intensity_mean；Intensity_min；Intensity_max
  plot_1 <- plotQC_hist(spc_reor_filt_qc,Noise_mean,A,"Noise mean")
  plot_2 <- plotQC_hist(spc_reor_filt_qc,Noise_sd,B,"Noise sd")
  plot_3 <- plotQC_hist(spc_reor_filt_qc,Signal_max,C,"Signal max")
  plot_4 <- plotQC_hist(spc_reor_filt_qc,Intensity_mean,D,"Intensity mean")
  plot_5 <- plotQC_hist(spc_reor_filt_qc,Intensity_min,E,"Intensity min")
  plot_6 <- plotQC_hist(spc_reor_filt_qc,Intensity_max,F,"Intensity max")
  
  plot <- plot_1+plot_2+plot_3+plot_4+plot_5+plot_6
  ggsave(filename=paste(outpath,"//",name,".png", sep=""),plot=plot, limitsize=T,width = 10,height = 7)
}

plot_QC_point <- function(spc_reor_filt_qc,outpath,name,a){
  
  color_pigment_props <- c("#08306B","#313695","#4575B4","#74ADD1",
                           "#33A02C","#B2DF8A","#FFFF99","#FEE090",
                           "#FDBF6F","#FDAE61","#F46D43","#A50026")
  color_pigment_props <- colorRampPalette(color_pigment_props)(n=100)
  
  plot_1 <- ggplot(spc_reor_filt_qc,aes(x=Ori_Intensity_mean,y=Ori_Intensity_max))+
    geom_vline(aes(xintercept=1), colour="black", linetype="dashed",size = 1)+
    geom_hdr_points(probs = seq(0.99,0.03,-0.01),size = 0.5)+
    scale_fill_manual(values = color_pigment_props,aesthetics = c("color")) +
    default_theme()+
    theme(
      axis.title = element_text(size = 15,family = "Arial"), 
      axis.text = element_text(size = 10,family = "Arial"),
      legend.position = "none")
  
  plot_2 <- ggplot(spc_reor_filt_qc,aes(x=Ori_Noise_mean,y=Pre_Noise_mean))+
    geom_vline(aes(xintercept=1), colour="black", linetype="dashed",size = 1)+
    geom_hdr_points(probs = seq(0.99,0.03,-0.01),size = 0.5)+
    scale_fill_manual(values = color_pigment_props,aesthetics = c("color")) +
    default_theme()+
    theme(
      axis.title = element_text(size = 15,family = "Arial"), 
      axis.text = element_text(size = 10,family = "Arial"),
      legend.position = "none")
  
  plot_3 <- ggplot(spc_reor_filt_qc,aes(x=Ori_Intensity_min,y=Ori_Intensity_max))+
    geom_vline(aes(xintercept=1), colour="black", linetype="dashed",size = 1)+
    geom_hdr_points(probs = seq(0.99,0.03,-0.01),size = 0.5)+
    scale_fill_manual(values = color_pigment_props,aesthetics = c("color")) +
    default_theme()+
    theme(
      axis.title = element_text(size = 15,family = "Arial"), 
      axis.text = element_text(size = 10,family = "Arial"),
      legend.position = "none")
  plot_4 <- ggplot(spc_reor_filt_qc,aes(x=Pre_Noise_mean,y=Pre_Noise_sd))+
    geom_vline(aes(xintercept=1), colour="black", linetype="dashed",size = 1)+
    #geom_abline(slope = 1.2,intercept = 0.1,linetype = "dashed", colour = "darkgrey",size= 1) +
    geom_hdr_points(probs = seq(0.99,0.03,-0.01),size = 0.5)+
    scale_fill_manual(values = color_pigment_props,aesthetics = c("color")) +
    default_theme()+
    scale_x_continuous(limits = c(0,a)) +
    scale_y_continuous(limits = c(0,a)) +
    theme(
      axis.title = element_text(size = 15,family = "Arial"), 
      axis.text = element_text(size = 10,family = "Arial"),
      legend.position = "none")
  plot_5 <- ggplot(spc_reor_filt_qc,aes(x=Ori_Intensity_mean,y=Ori_Noise_mean))+
    geom_vline(aes(xintercept=1), colour="black", linetype="dashed",size = 1)+
    geom_hdr_points(probs = seq(0.99,0.03,-0.01),size = 0.5)+
    scale_fill_manual(values = color_pigment_props,aesthetics = c("color")) +
    default_theme()+
    theme(
      axis.title = element_text(size = 15,family = "Arial"), 
      axis.text = element_text(size = 10,family = "Arial"),
      legend.position = "none")
  plot_6 <- ggplot(spc_reor_filt_qc,aes(x=Pre_Signal_max,y=Ori_Noise_mean))+
    geom_vline(aes(xintercept=1), colour="black", linetype="dashed",size = 1)+
    geom_hdr_points(probs = seq(0.99,0.03,-0.01),size = 0.5)+
    scale_fill_manual(values = color_pigment_props,aesthetics = c("color")) +
    scale_x_continuous(limits = c(0,2)) +
    default_theme()+
    theme(
      axis.title = element_text(size = 15,family = "Arial"), 
      axis.text = element_text(size = 10,family = "Arial"),
      legend.position = "none")
  plot <- plot_1+plot_2+plot_3+plot_4+plot_5+plot_6
  ggsave(filename=paste(outpath,"//",name,".png", sep=""),plot=plot, limitsize=T,width = 10,height = 7)
}
