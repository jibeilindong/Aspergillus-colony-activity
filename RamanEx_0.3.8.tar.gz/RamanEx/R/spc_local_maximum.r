Spc_local_maximum <- function(spc,peak_location,step)
{
  if(length(spc) < (2*step-1))
  {
    peak_location[j] <- which.max(spc)
  }else if(j < step ) 
  {
    peak_location[j] <- which.max(spc[peak_location[j] : (peak_location[j]+step)]) + peak_location[j] -1
  }else if(j > step & (j + step) <= length(spc))
  {
    peak_location[j] <- which.max(spc[(peak_location[j]-step) : (peak_location[j]+step)]) + peak_location[j] -step-1
  }else if(j > step & (j + step) > length(spc))
  {
    peak_location[j] <- which.max(spc[(peak_location[j]-step) : length(spc)]) + peak_location[j] -step-1
  }
  
  
  return(peak_location)
}