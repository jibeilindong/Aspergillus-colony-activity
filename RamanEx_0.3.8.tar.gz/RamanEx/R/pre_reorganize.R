pre_reorganize <- function(spc_reor_filt,meta_filt,from = 500,to = 3200)
{
  max_wave_vector <- levels(factor(meta_filt$max_wave))
  spc_reor_filt_all <- c()
  for(i in max_wave_vector)
  {
    spc_reor_filt_i <- filter(spc_reor_filt,filename %in% filter(meta_filt,max_wave == i)$filename)
    spc_reor_filt_i <- spc_reor_filt_i %>% 
      dplyr::select(names(spc_reor_filt_i[1,!is.na(spc_reor_filt_i[1,])]))
    if(is.null(ncol(spc_reor_filt_all)))
    {
      wavenum_all <- as.numeric(as.character(colnames(spc_reor_filt_i[,-1])))
      spc_reor_filt_all <- spc_reor_filt_i[,c(1,(which.min(abs(wavenum_all - from))+1):(which.min(abs(wavenum_all - to))+1))]
    }else{
      wavenum_all <- as.numeric(as.character(colnames(spc_reor_filt_all[,-1])))
      wavenum_i <- as.numeric(as.character(colnames(spc_reor_filt_i[,-1])))
      inds <- c()
      for(j in wavenum_all)
      {
        inds <- c(inds,which.min(abs(wavenum_i - j)))
      }
      spc_reor_filt_j <- spc_reor_filt_i[,c(1,inds+1)]
      colnames(spc_reor_filt_j) <- colnames(spc_reor_filt_all)
      spc_reor_filt_all <- rbind(spc_reor_filt_all,spc_reor_filt_j)
    }
  }
  return(spc_reor_filt_all)
}
