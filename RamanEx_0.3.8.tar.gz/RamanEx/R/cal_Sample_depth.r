
RTCS_group <- function(CD_ratio_groups,Original_value = 20,Max_value = 150,by = 25)
{
  alldata  <-as.data.table(CD_ratio_groups)
  factor_alldata <- levels(factor(alldata$Group))
  setkey(alldata,Group)
  
  alldata_N <- alldata_n <- c()
  for (i in 1:length(factor_alldata))
  {
    all_data_i <- alldata[factor_alldata[i]]
    if((nrow(all_data_i)-Original_value) > by & (nrow(all_data_i)-Original_value) < Max_value)
    {
      for (j in seq(by,(nrow(all_data_i)-Original_value),by = by))
      {
        alldata_i <- sample(all_data_i,(j+Original_value))
        alldata_i$N <- j
        alldata_n <- rbind(alldata_n,alldata_i)
      }
    }else if((nrow(all_data_i)-Original_value) > Max_value)
    {
      for (j in seq(by,Max_value,by = by))
      {
        alldata_i <- sample(all_data_i,(j+Original_value))
        alldata_i <- data.frame(alldata_i,N = j)
        alldata_n <- rbind(alldata_n,alldata_i)
      }
    }
    alldata_N <- rbind(alldata_N,alldata_n)
    alldata_n <- c()
  }
  return(alldata_N)
}

RTCS_Pvalue <- function(alldata_N,Original_value = 20)
{
  alldata_N  <-as.data.table(alldata_N)
  factor_alldata <- select(alldata_N,Group,N)
  factor_alldata <- factor_alldata[!duplicated(factor_alldata),]
  setkey(alldata_N,Group,N)
  
  Pvaluedata_n <- c()
  for (i in 1:nrow(factor_alldata))
  {
    Pvalue <- as.numeric(Sampling_depth2(alldata_N[factor_alldata[i,]]$CD_ratio))
    if (length(Pvalue) == 280)
    {
      Number_sample <- 1:280 
    }else
    {
      Number_sample = c(1:(length(alldata_N[factor_alldata[i,]]$CD_ratio)-Original_value))
    }
    Pvaluedata <- data.frame(Pvalue = Pvalue,Group = factor_alldata[i,1],N = factor_alldata[i,2],Number_sample,Number_sample_max_Pvalue = Number_sample[max(which(Pvalue < 0.95))])
    Pvaluedata_n <- rbind(Pvaluedata_n,Pvaluedata)
  }
  return(Pvaluedata_n)
}

####实际测量使用的方法
Sampling_depth2 <- function(CD_ratio)
{
  Time_sample <- 1000
  Pvalue <- Mean_sample <- c()
  if (length(CD_ratio) < 300)
  { Number_sample <- c(1:(length(CD_ratio)-20)) }
  else { Number_sample <- c(1:280) }
  
  for (n in Number_sample )#length(CD_ratio_groups$CD_ratio)
  {
    
    Sample_x <- sample(CD_ratio,(20+n))
    last_Mean_sample_x <- mean(Sample_x)
    for (j in 1:Time_sample)
    { 
      Sample_y <- c(Sample_x,sample(CD_ratio,5))
      factor_a <- mean(Sample_y)
      Mean_sample <- c(Mean_sample,factor_a)
    }
    Pvalue <- c(Pvalue,sum(abs(1-Mean_sample/last_Mean_sample_x) < 0.01)/Time_sample)
    Mean_sample <- c()
  }
  return(Pvalue)
}

Pvalue_plot <- function(Pvaluedata_n,outpath)
{
  plot<-ggplot(Pvaluedata_n,aes(x=Number_sample,y=Pvalue,color = N))+
    theme(axis.ticks = element_blank())+  theme_bw()+
    theme(panel.grid.major =element_blank(), panel.grid.minor = element_blank()) +  
    theme(axis.text = element_text(size=15))+theme(legend.text = element_text(size=15))+
    theme(axis.text.x = element_text(size=10,angle = 0))+
    theme(legend.title = element_text(size=15))+
    theme(axis.title= element_text( family = "myFont" ,size=20))+
    #geom_boxplot(aes(group=N),alpha=1/5)+#
    geom_point(aes(group=N,color = N))+
    #geom_point(aes(x=N,y=mean,color = LM))+
    #geom_line(aes(x=Concentration.of.antibiotics,y=CD_ratio_groups_summary$CD_ratio_groups_mean,colour=Strain))+
    facet_grid( . ~ N,scales = "free_x" )+
    #stat_smooth(aes(group=N),method = "loess",size=1,level = 0.9,col = "black")+#
    theme(strip.text = element_text(size=15,family = "myFont"))+
    geom_hline(aes(yintercept=0.95), colour="red", linetype="dashed")+
    geom_vline(aes(xintercept=Number_sample_max_Pvalue), colour="red", linetype="dashed")+
    geom_text(aes(x=Number_sample_max_Pvalue-5,y=0.93,label=paste(Number_sample_max_Pvalue,"cells",sep=" ")),colour="#990000",size=5)+
    xlab("Sampling depth")+
    ylab(expression(paste('Probability (RE'[mean],'<0.01)',sep="")) )
  plot
  ggsave(filename=paste(outpath,"//","CD_ratio_实时计算结果.png", sep=""),plot=plot, limitsize=T,width = 15,height = 8)
}

Sample_depth <- function(CD_ratio_groups,outpath)
{
  CD_ratio_groups <- CD_ratio(data_baseline_normalization)
  alldata_N <- RTCS_group(CD_ratio_groups)
  Pvaluedata_n <- RTCS_Pvalue(alldata_N)
  Pvalue_plot(Pvaluedata_n,outpath)
}




