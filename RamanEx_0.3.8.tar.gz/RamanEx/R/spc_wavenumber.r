### 获取特定范围的光谱 spc to spc
spc_waveumber <- function(spc, from, to) {
  spc <- as.data.frame(spc)
  wave_nums <- as.numeric(colnames(spc))
  start <- which.min(abs(wave_nums - from))
  end <- which.min(abs(wave_nums - to))
  final_spc <- spc[, c(1,start:end)]
  return(final_spc)
}
