#' 获取特定位置的光谱——dataframe
#'
#' @param spc 
#' @param at 
#'
#' @return
#' @export
#'
#' @examples
spc_at_wavenumber <- function(spc,at)
{
  wave_nums <- as.numeric(as.character(colnames(spc)))
  if (length(at) == 1)
  {
    start <- which.min(abs(wave_nums-at))
  }else
  {
    for (i in 1:length(at))
    {
      start_i <- which.min(abs(wave_nums-at[i]))
      if (i == 1)
      {
        start <- start_i
      }else
      {
        start <- c(start,start_i)
      }
    }
  }
  final_spc <- spc[,c(1,start)]
  return(final_spc)
}
