plotspc_tile <- function(spc_melt_all,outpath,name){
  RICH_data_wavenumber <- sort(unique(spc_melt_all$wavenumber))
  myPal <- colorRampPalette(c("darkblue","white","gray","gold","orange","red"))(n=1000)
  plot_tile <- ggplot(spc_melt_all, aes(x=factor(wavenumber), y=factor(Number), fill=value)) +
    geom_tile() + theme_bw() + coord_equal(ratio = 1) +
    scale_x_discrete(breaks = RICH_data_wavenumber[seq(1,length(RICH_data_wavenumber),20)]) +
    scale_fill_gradientn(colours =myPal) +
    theme(panel.grid = element_blank(),
          panel.border = element_blank(),
          legend.title = element_blank(),
          legend.key.width = unit(10,"pt"),
          legend.key.height = unit(50, "pt"),
          axis.ticks = element_blank(),
          axis.title = element_blank(),
          axis.text.x = element_text(size = 10,angle = 45,hjust = 1,vjust =1),
          axis.text.y = element_blank(),
          axis.text = element_text()
    )
  ggsave(filename=paste(outpath,"//",name,".png", sep=""),
         plot=plot_tile, limitsize=T,width = 20,height = 10)
}

