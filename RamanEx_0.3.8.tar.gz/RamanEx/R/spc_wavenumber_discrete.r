#' get spectrum intensity value at discrete wavenumbers
#'
#' @param spc the spec as dataframe object
#' @param at a vector of wavenumbers
#' @return array object of spectrum intensity value
#'
#' @examples
#' spc_wavenumber_discrete(spc, 800)
#' spc_wavenumber_discrete(spc, c(800, 1000, 1500))
spc_wavenumber_discrete <- function(spc, at) {
  wave_nums <- as.numeric(colnames(spc))
  inds <- c()
  for (i in 1:length(at)) {
    ind <- which.min(abs(wave_nums - at[i]))
    inds <- c(inds, ind)
  }
  final_spc <- spc[, inds]
  return(final_spc)
}

