save_hyperSpec <- function(data_hyperSpec, filename, path) {
  data_hyperSpec_df <- cbind(
    select(as.data.frame(data_hyperSpec), -spc, -.row),
    as.data.frame(data_hyperSpec$spc)
  )
  fwrite(data_hyperSpec_df,
    paste(path, filename, sep = "/"),
    row.names = F,
    col.names = T,
    quote = F,
    sep = "\t"
  )
}
