#' Title
#'
#' @param hyperspec 
#' @param Name_group 
#'
#' @return
#' @export
#'
#' @examples
cal_wavenum_summary <- function(hyperspec,Name_group)
{
  meta <- as.data.frame(tstrsplit(gsub(".txt","",basename(hyperspec$filename)),"_"),col.names = Name_group)
  meta <- mutate(meta,Group = apply(dplyr::select(meta,starts_with("group")),1,function(i) paste(i,collapse = "_")))
  hyperspec@data <- cbind(meta,hyperspec@data)
  wavelength_summary <- data.frame(Group = hyperspec$Group[1],
                                   first_wavnumber = hyperspec@wavelength[1],
                                   length = length(hyperspec@wavelength))
  return(wavelength_summary)
}